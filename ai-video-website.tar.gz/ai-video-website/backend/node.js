npm init -y
npm install express

node backend/app.js
