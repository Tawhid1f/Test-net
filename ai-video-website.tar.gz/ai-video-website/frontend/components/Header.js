import React from 'react';

function Header() {
    return (
        <header>
            <h1>AI Video Generator</h1>
        </header>
    );
}

export default Header;
